package com.nagarro.LibraryManagement1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryManagement1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
